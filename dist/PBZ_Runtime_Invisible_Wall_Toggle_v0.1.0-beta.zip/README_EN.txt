Phantom Blade Zero: Runtime Invisible Wall Toggle (beta 0.1.0)

Press F9 in game to enable; press F9 again to restore the responses this mod changed. Disabled at every game launch. The mod scans loaded BP_SplineWall_C actors every three seconds and sets their DynamicMeshComponent Pawn response to Ignore. Newly streamed walls may take up to approximately three seconds. There is no on-screen indicator; see [NOSPLINEWALL] in UE4SS.log.

This only affects the specified wall class; it does not remove every type of barrier or add collision to scenery. You can walk into scenery, get stuck, fall outside the map, or disrupt progression. Back up saves and return to a safe playable area before restoring walls. Game autosaves may still record progression. Mods that change the same collision or bind F9 may conflict.

Test environment: Windows, Steam build 26266538, game-specific UE4SS v3.0.1-1195-g1ceefac8. The original prototype was exercised in game; this release copy only removes machine-specific log paths and still needs independent in-game release testing.

Install (game closed):
1. Install the Phantom Blade Zero UE4SS package separately: https://github.com/KintaroModding/ue4ss/releases/tag/v3.0.1-1195-g1ceefac8 . Follow its instructions and extract it into the game's platform\steam folder, next to the large PBZ.exe.
2. Copy this archive's PBZNoSplineWall folder into platform\steam\ue4ss\Mods\, resulting in Mods\PBZNoSplineWall\Scripts\main.lua.
3. Add PBZNoSplineWall : 1 to the existing Mods\mods.txt, or enable its existing entry. Do not replace the whole mods.txt.
4. Start the game, load a save, then press F9. Return to a safe playable area before pressing F9 again.

Uninstall: exit the game, remove or disable the PBZNoSplineWall entry in mods.txt, and delete only the Mods\PBZNoSplineWall folder. UE4SS and other mods are not included and should be left alone.
