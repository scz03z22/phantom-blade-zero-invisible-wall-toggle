影之刃零：实时去空气墙（测试版 0.1.0）

功能
游戏内按 F9 切换去空气墙：第一次开启，再按一次恢复。本模组每 3 秒检查当前已加载的 BP_SplineWall，关闭该类墙体对玩家 Pawn 的阻挡；场景流送进来后可能需要最多约 3 秒。开关只在本次游戏进程内有效，每次启动游戏默认关闭。游戏画面没有开关提示，可查看 UE4SS.log 中 [NOSPLINEWALL] 的记录。

范围与限制
本模组只处理 BP_SplineWall_C 的 DynamicMeshComponent，不保证移除所有空气墙；也不添加岩石碰撞，不会自动判断哪些区域可以安全进入。关闭墙体可能进入无碰撞模型、卡住或掉出地图，也可能影响任务流程。建议先备份存档，在正常可玩区域再按 F9 恢复；若已卡住，可读取安全存档。游戏自动存档仍可能记录角色进度。与同样修改这些墙体或使用 F9 的模组可能冲突。

测试环境
Windows Steam 版，Steam build 26266538；适配 Phantom Blade Zero 的 UE4SS v3.0.1-1195-g1ceefac8。本游戏及 UE4SS 更新后可能不兼容。实际游戏中已测试原型的开启、恢复及岩石阻挡；本发行包仅去除了本机专用日志路径，仍建议在发布前对发行包进行独立游戏内验证。

安装
1. 关闭游戏。安装适配 Phantom Blade Zero 的 UE4SS：https://github.com/KintaroModding/ue4ss/releases/tag/v3.0.1-1195-g1ceefac8 。选择 phantombladezero_ue4ss 压缩包，按照该项目说明解压到游戏目录 platform\steam（大 PBZ.exe 同目录）。本模组不包含 UE4SS。
2. 将本压缩包内的 PBZNoSplineWall 文件夹复制到 游戏目录\platform\steam\ue4ss\Mods\ 。最终路径应为 Mods\PBZNoSplineWall\Scripts\main.lua。
3. 打开现有 Mods\mods.txt，在末尾添加一行 PBZNoSplineWall : 1；如已有该项，改为 1，不要添加重复项。不要用本包覆盖其他模组的 mods.txt。
4. 启动游戏并读取存档。功能默认关闭；按 F9 开启，回到安全区域后再按 F9 恢复。

卸载
关闭游戏，在 Mods\mods.txt 删除或禁用 PBZNoSplineWall 条目，再删除 Mods\PBZNoSplineWall 文件夹。不要删除其他模组或 UE4SS。下次启动后，本模组不再运行。

诊断
若 F9 无效，检查 UE4SS 是否加载、本模组目录及 mods.txt 条目，并检查 platform\steam\ue4ss\UE4SS.log 中的 [NOSPLINEWALL] 输出；也要检查 F9 是否被其他软件或模组占用。无法恢复时，进入安全位置后退出并重新启动游戏。
